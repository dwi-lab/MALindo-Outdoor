define( function() {

	// [[Class]] -> type pairs
	return {};
} );
